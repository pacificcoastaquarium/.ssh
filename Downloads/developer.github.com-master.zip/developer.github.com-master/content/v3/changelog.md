---
title: GitHub API Changelog
---

The API changelog can now be found on the [homepage](/). Please update your links.
