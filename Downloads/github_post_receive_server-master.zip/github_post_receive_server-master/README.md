# GitHub Post Commit Server

This is a template server for using with the github callbacks. Extend it, make
it your own, enjoy it. I've added a rackup for those of you that would prefer
to use an evented server for this application. (It's kinda ideal in this case)

Sadly, the way rubygems packs up binaries, I will need some assistance making
the rackup work from the default binary install path.

For more details please see the following guide on GitHub:
http://help.github.com/post-receive-hooks

And please, take a look at the source, that's what it's there for.
