require 'github_post_receive_server/rack_app'
