$TESTING=true
require 'bacon'
require 'github_post_receive_server'
